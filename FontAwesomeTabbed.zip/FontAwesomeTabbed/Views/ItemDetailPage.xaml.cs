﻿using $safeprojectname$.ViewModels;
using Xamarin.Forms;

namespace $safeprojectname$.Views
{
    public partial class ItemDetailPage : ContentPage
    {
        public ItemDetailPage()
        {
            InitializeComponent();
            BindingContext = new ItemDetailViewModel();
        }
    }
}
﻿using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace $safeprojectname$.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class FARegularPage : ContentPage
    {
        public FARegularPage()
        {
            InitializeComponent();
        }
    }
}
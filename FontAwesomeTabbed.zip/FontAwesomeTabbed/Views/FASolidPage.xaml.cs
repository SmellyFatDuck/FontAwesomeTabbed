﻿using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace $safeprojectname$.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class FASolidPage : ContentPage
    {
        public FASolidPage()
        {
            InitializeComponent();
        }
    }
}
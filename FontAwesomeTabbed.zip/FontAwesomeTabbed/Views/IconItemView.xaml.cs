﻿
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace $safeprojectname$.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class IconItemView : ContentView
    {
        public IconItemView()
        {
            InitializeComponent();
        }
    }
}
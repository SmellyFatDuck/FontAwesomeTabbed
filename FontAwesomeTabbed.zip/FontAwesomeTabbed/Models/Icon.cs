﻿namespace $safeprojectname$.Models
{
    public class Icon
    {
        public string Glyph { get; set; }
        public string Name { get; set; }
        public string FontFamily { get; set; }
    }
}
